# SKY MARKETINGZ

This is a static website for Sky Marketingz.

## Structure
- `index.html`: Home page
- `about.html`, `products.html`, `poultry.html`, `contact.html`: Inner pages
- `css/style.css`: Main stylesheet
- `js/script.js`: Main JavaScript logic (Mobile menu, animations)
- `images/`: Asset directory

## How to Run
Simply open `index.html` in your web browser. No installation or server required.
For best experience, you can use a local server (like Live Server in VS Code).
